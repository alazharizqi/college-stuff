import java.util.Scanner;
public class Task3{
	public static void main(String args []){
		float suhu, celcius, reaumur, fahrenheit, kelvin;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter suhu: ");
suhu = sc.nextInt();
celcius = suhu;
reaumur = (float)4/5 * celcius;
fahrenheit = (9/5*celcius) + 32;
kelvin = celcius + 273;
		System.out.println("Celcius" + "=" + celcius);
		System.out.println("Reamur" + "=" + reaumur);
		System.out.println("Fahrenheit" + "=" + fahrenheit );
		System.out.println("Kelvin" + "=" + kelvin );
	}
}