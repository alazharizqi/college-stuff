public class Task1 {
	public static void main(String[] args) {
		String campus = "POLINEMA";
		int grade = 1;
		char _class = 'H';
		int integer = 10;
		double fractionNumber = 3.33333;
		char character = 'C';

		System.out.println("I am a "+campus+" student, class "+grade+_class);
		System.out.println("i'm learning to display values :");
		System.out.println("\t Integer " + integer);
		System.out.println("\t Fraction " + fractionNumber);
		System.out.println("\t Character " + character);
	}
}
