import java.util.Scanner;
public class Triangle {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int radius, height;
		float volume,phi=3.14F;
		System.out.println ("Enter the radius");
		radius = sc.nextInt ();
		System.out.println ("Enter height");
		height = sc.nextInt ();
		volume = phi*radius*radius*height;
		System.out.println ("Tube volume:" + volume);
	}

}
