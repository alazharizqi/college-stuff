public class ExampleVariable {
	public static void main(String[] args){
		String hobby = "Bermain Petak Umpet";
		boolean amazing = true; 
		char jenis = 'L';
		byte _umur = 20;
		double $ipk = 3.24, tinggi = 1.78;
		System.out.println(hobby);
		System.out.println("Apakah amazing? " + amazing);
		System.out.println("Umurku saat ini: " + _umur);
		System.out.println(String.format("Saya beripak %s, dengan tinggi badan %s", $ipk, tinggi));


	}

}
