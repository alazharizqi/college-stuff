import java.util.Scanner;
public class Omar1 {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        Scanner sc1=new Scanner(System.in);
        Scanner sc2=new Scanner(System.in);
        Scanner sc3=new Scanner(System.in);

        String menu1, condition;
        int  amount, discount, price, price1, price2, price3, total;
        char flavor, drink, snacks;
        System.out.println("========================================================");
        System.out.println("/                Welcome to Omar's shop                /");
        System.out.println("========================================================");
        System.out.println("/         in Omar's we offer the following             /");
        System.out.print("1. Shisha ");
        System.out.print("           2. Drinks ");
        System.out.print("               3. Snacks ");
        System.out.println(" ");
        System.out.println("========================================================");
        System.out.println("========================================================");
        System.out.println("/         Let's Start with Shishas Menu                /");
        System.out.println("========================================================");
        System.out.println("/         We offer these flavors of Shisha             /");
        System.out.println("a. Double Apple                                   Rp100K");
        System.out.println("b. Strawberry                                     Rp150K");
        System.out.println("========================================================");
        System.out.println("Would you like to order shisha? (y/n)");
        System.out.println("========================================================");
        menu1=sc.nextLine();
        if (menu1.equalsIgnoreCase("y")){
            System.out.println("========================================================");
            System.out.println("Choose a Flavor");
            System.out.println("a. Double Apple                                         ");
            System.out.println("b. Strawberry                                           ");
            System.out.println("========================================================");
            flavor = sc2.next().charAt(0);
            if (flavor ==('a')){
            System.out.println("You get one for free if purchase more than 2");
            System.out.println("If you purchase 2 you get a discount of 10% ");
            System.out.println("========================================================");
            System.out.println("How many do you want?");
            amount=sc1.nextInt();
                if (amount>2){
                price = 100000;
                price1 = (amount*price) - 100000;
                System.out.println("========================================================");
                System.out.println("You get one for free");
                System.out.println("The price is :Rp" + price1);
                System.out.println("========================================================");
                }else if(amount==2) {
                discount = 20000;
                price = 200000;
                price1 = price - discount;  
                System.out.println("========================================================");
                System.out.println("You get a discount of 10%");
                System.out.println("The price is : Rp" + price1);
                System.out.println("========================================================");
                }else {
                price1 =amount*100000;
                System.out.println("========================================================");
                System.out.println("The price is : Rp"+ price1);
                System.out.println("========================================================");
                }
            }else if (flavor==('b')){
            System.out.println("========================================================");    
            System.out.println("You get one for free if purchase more than two");
            System.out.println("If purchase two you get a discount of 10% ");
            System.out.println("========================================================");
            System.out.println("How many do you want");
            amount=sc1.nextInt();
                if (amount>2){
                price = 150000;
                price1 = (amount*price) - 150000;    
                System.out.println("========================================================");
                System.out.println("You get one for free");
                System.out.println("The price is :Rp" + price1);
                System.out.println("========================================================");
                }else if (amount==2){
                discount = 30000;
                price = 300000;
                price1 = price - discount;
                System.out.println("========================================================");
                System.out.println("You get a discount of 10% :" );
                System.out.println("The price is : Rp" + price1);
                System.out.println("========================================================");
                }else{
                price = amount*150000;
                System.out.println("========================================================");
                System.out.println("The price is : Rp"+ price);
                System.out.println("========================================================");
                }
            }
            System.out.println("========================================================");
            System.out.println("========================================================");
            System.out.println("/           This is the Drinks Menu                    /");
            System.out.println("a. Tea                                 Ice:Rp8K/Hot:Rp5K");
            System.out.println("b. Soda                           Cola:Rp10K/Pepsi:Rp13K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a drink? (y/n)");
            System.out.println("========================================================");
            menu1=sc.nextLine();
            if (menu1.equalsIgnoreCase("y")){
            System.out.println("========================================================");    
            System.out.println("Choose a drink ");
            System.out.println("a. Tea                                                  ");
            System.out.println("b. Soda                                                 ");
            System.out.println("========================================================");
            drink = sc1.next().charAt(0);
                if (drink == ('a')){
                System.out.println("Ice/Hot");
                System.out.println("========================================================");
                condition = sc.nextLine();
                    if (condition.equalsIgnoreCase("hot")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 5000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else if(condition.equalsIgnoreCase("Ice")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 8000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else {
                    System.out.println("Invalid input please try again");
                    }
                }else if(drink==('b')){
                System.out.println("Cola/Pepsi");
                System.out.println("========================================================");
                condition = sc.nextLine();
                    if (condition.equalsIgnoreCase("Cola")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 10000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else if(condition.equalsIgnoreCase("Pepsi")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 13000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else {
                    System.out.println("Invalid input please try again");
                    }
                }else {
            System.out.println("invalid Input please try again");
            }
            System.out.println("========================================================");
            System.out.println("========================================================");    
            System.out.println("/           This is the Snacks Menu                    /");
            System.out.println("a. Gum                                                2K");
            System.out.println("b. Chips                                             10K");
            System.out.println("c. Choclate                                           9K");
            System.out.println("d. Pack of Candy                                      4K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a Snack? (y/n)");
            System.out.println("========================================================");
            menu1=sc3.nextLine();
            if (menu1.equalsIgnoreCase("y")){
                System.out.println("========================================================");
                System.out.println("Choose a snack");
                System.out.println("a. Gum                                                  ");
                System.out.println("b. Chips                                                ");
                System.out.println("c. Choclate                                             ");
                System.out.println("d. Pack of Candy                                        ");
                System.out.println("========================================================");
                snacks = sc2.next().charAt(0);
            switch (snacks) {
                case 'a':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 2000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'b':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 10000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'c':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 9000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'd':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 4000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                default:
                    System.out.println("Invalid input please try again");
                    break;
                        }
                    }else {
                System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
                }
        }else if (menu1.equalsIgnoreCase("n")){
            System.out.println("========================================================");
            System.out.println("========================================================");
            System.out.println("/           This is the Snacks Menu                    /");
            System.out.println("a. Gum                                                2K");
            System.out.println("b. Chips                                             10K");
            System.out.println("c. Choclate                                           9K");
            System.out.println("d. Pack of Candy                                      4K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a Snack? (y/n)");
            System.out.println("========================================================");
            menu1=sc.nextLine();
            if (menu1.equalsIgnoreCase("y")){
                System.out.println("========================================================");
                System.out.println("Choose a snack");
                System.out.println("a. Gum                                                  ");
                System.out.println("b. Chips                                                ");
                System.out.println("c. Choclate                                             ");
                System.out.println("d. Pack of Candy                                        ");
                System.out.println("========================================================");
                snacks = sc2.next().charAt(0);
            switch (snacks) {
                case 'a':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 2000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'b':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 10000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'c':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 9000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'd':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 4000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                default:
                    System.out.println("Invalid input please try again");
                    break;
                        }
                    }else {
                System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
                }
            }else{
            System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
            }
        }else if (menu1.equalsIgnoreCase("n")){
            System.out.println("========================================================");
            System.out.println("========================================================");
            System.out.println("/           This is the Drinks Menu                    /");
            System.out.println("a. Tea                                 Ice:Rp8K/Hot:Rp5K");
            System.out.println("b. Soda                           Cola:Rp10K/Pepsi:Rp13K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a drink? (y/n)");
            System.out.println("========================================================");
            menu1=sc.nextLine();
            if (menu1.equalsIgnoreCase("y")){
            System.out.println("========================================================");
            System.out.println("Choose a drink ");
            System.out.println("a. Tea                                                  ");
            System.out.println("b. Soda                                                 ");
            System.out.println("========================================================");
            drink = sc1.next().charAt(0);
                if (drink == ('a')){
                System.out.println("Ice/Hot");
                System.out.println("========================================================");
                condition = sc.nextLine();
                    if (condition.equalsIgnoreCase("hot")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 5000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else if(condition.equalsIgnoreCase("Ice")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 8000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else {
                    System.out.println("Invalid input please try again");
                    }
                }else if(drink==('b')){
                System.out.println("Cola/Pepsi");
                System.out.println("========================================================");
                condition = sc.nextLine();
                    if (condition.equalsIgnoreCase("Cola")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 10000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else if(condition.equalsIgnoreCase("Pepsi")){
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price2 = 13000*amount;
                    System.out.println("========================================================");
                    System.out.println("The price is :Rp"+ price2);
                    System.out.println("========================================================");
                    }else {
                    System.out.println("Invalid input please try again");
                    }
                }else {
            System.out.println("invalid Input please try again");
            }
            System.out.println("========================================================");
            System.out.println("========================================================");
            System.out.println("/           This is the Snacks Menu                    /");
            System.out.println("a. Gum                                                2K");
            System.out.println("b. Chips                                             10K");
            System.out.println("c. Choclate                                           9K");
            System.out.println("d. Pack of Candy                                      4K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a Snack? (y/n)");
            System.out.println("========================================================");
            menu1=sc3.nextLine();
            if (menu1.equalsIgnoreCase("y")){
                System.out.println("========================================================");
                System.out.println("Choose a snack");
                System.out.println("a. Gum                                                  ");
                System.out.println("b. Chips                                                ");
                System.out.println("c. Choclate                                             ");
                System.out.println("d. Pack of Candy                                        ");
                System.out.println("========================================================");
                snacks = sc2.next().charAt(0);
            switch (snacks) {
                case 'a':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 2000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'b':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 10000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'c':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 9000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'd':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 4000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                default:
                    System.out.println("Invalid input please try again");
                    break;
                        }
                    }else {
                System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
                }
        }else if (menu1.equalsIgnoreCase("n")){
            System.out.println("========================================================");
            System.out.println("========================================================");
            System.out.println("/           This is the Snacks Menu                    /");
            System.out.println("a. Gum                                                2K");
            System.out.println("b. Chips                                             10K");
            System.out.println("c. Choclate                                           9K");
            System.out.println("d. Pack of Candy                                      4K");
            System.out.println("========================================================");
            System.out.println("Would you like to order a Snack? (y/n)");
            System.out.println("========================================================");
            menu1=sc.nextLine();
            if (menu1.equalsIgnoreCase("y")){
                System.out.println("========================================================");
                System.out.println("Choose a snack");
                System.out.println("a. Gum                                                  ");
                System.out.println("b. Chips                                                ");
                System.out.println("c. Choclate                                             ");
                System.out.println("d. Pack of Candy                                        ");
                System.out.println("========================================================");
                snacks = sc2.next().charAt(0);
            switch (snacks) {
                case 'a':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 2000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'b':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 10000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'c':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 9000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                case 'd':
                    System.out.println("How many do you want?");
                    amount= sc.nextInt();
                    price3 = amount * 4000;
                    System.out.println("========================================================");
                    System.out.println("The price is Rp:"+price3);
                    System.out.println("========================================================");
                    break;
                default:
                    System.out.println("Invalid input please try again");
                    break;
                        }
                    }else {
                System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
                }
            }           
        }else{
        System.out.println("Invalid input please try again");
        }System.out.println("Thanks for visiting Omar's, have a nice day\u2764");
    }       
}