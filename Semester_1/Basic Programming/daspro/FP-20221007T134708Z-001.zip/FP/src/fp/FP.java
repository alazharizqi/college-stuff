/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fp;

/**
 *
 * @author MICROSOFT
 */
import java.text.NumberFormat;
import java.util.*;

class Fb {

    static String car[][] = new String[10][6];
    static int temp = 0;

    static int getTemp() {
        for (int i = 0; i < car.length; i++) {
            for (int j = 0; j < car[0].length; j++) {
                if (car[i][j].equalsIgnoreCase(null)) {
                    temp = i;
                    break;
                }
            }
        }
        return temp;
    }

    static void viewcar() {
        for (int k = 0; k < temp; k++) {
            for (int l = 0; l < car[0].length; l++) {
                System.out.print(car[k][l] + ", ");
            }
        }
        temp++;
    }

    static void addNewCar(String model , String plat) {
        System.out.println("Entared car");
        for (int i = temp; i < temp + 1; i++) {
            for (int j = 0; j < car[0].length; j++) {
                car[i][0] = model;
                car[i][1] = plat;
                car[i][2] = null;
                car[i][3] = null;
                car[i][4] = "available";
                car[i][5] = null;
            }
        }
        temp++;
    }

    static void rentCar(String model, String plat, String name, String id, String Rp) {
        for (int i = temp; i <= temp; i++) {
            for (int j = 0; j < car[0].length; j++) {
                car[i][0] = model;
                car[i][1] = plat;
                car[i][2] = name;
                car[i][3] = id;
                car[i][4] = "Rented";
                car[i][5] = Rp;
            }
        }
        temp++;
    }

    static void returncar(String id) {
        int ind = -1;
        for (int i = 0; i < car.length; i++) {
            if (id.equalsIgnoreCase(car[i][3])) {
                car[i][4] = "available";
                ind = i;
            }
        }
        if (ind >= 0) {
            System.out.println("customer :" + car[ind][2] + " have returnd the: " + car[ind][0] + " car wit Plat NO. " + car[ind][1] + " successfully");
        } else {
            System.out.println("this Customer never rent from us");
        }
    }

    public static String usernamepassword(String A, String B) {
        String um = "Omar", pw = "omar";
        if (A.equalsIgnoreCase(um) && B.equals(pw)) {
            System.out.println(r);
            return r;
        } else {
            System.out.println(w);
            return w;
        }
    }

    public static int carsReport(int d, int s) {
        int price = d * 45;
        if (s <= 2) {
            return price;
        } else {
            return price + 5;
        }
    }

    public static String[] Display() {
        String cst[] = {"Honda", "Volvo", "Ford", "Toyota", "Jeep", "GMC", "Land Rover", "Mercedes"};
        return cst;
    }

    public static boolean search(String b) {
        String[] search;
        search = Display();
        for (String search1 : search) {
            if (search1.equalsIgnoreCase(b)) {
                return true;
            }
        }
        return false;
    }

    public static void Report(String model, String plat, int days, String name, String id, String Rp) {
        System.out.println("===   ===   ===   Receipt   ===   ===   ===");
        System.out.println("-Model:             ||      " + model + "\n-plate NO.:         ||      " + plat + "\n-Duration:          ||      " + days + " Days" + "\n-Name:              ||      " + name + "\n-ID:                ||      " + id + "\n-Final price:       ||      " + Rp);
        System.out.println("===   ===   ===   =======   ===   ===   ===");
    }

    public static void main(String[] args) {
        String UN, PW, cek;
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        System.out.println("====OMAR'S FOR VEHICLES RENTING====");
        do {
            System.out.println("===============LOG IN==============");
            System.out.print("Username: ");
            UN = sc.nextLine();
            System.out.print("Password: ");
            PW = sc.nextLine();
            cek = usernamepassword(UN, PW);
            if (cek.equalsIgnoreCase(r)) {
                do {
                    System.out.println(" 1) Reserve/Rent a car. \n 2) Search for a car brand. \n 3) Display all the car brands. \n 4) Enter a new car \n 5) Display transactions. \n 6) Return a car. \n 7) Exit.");
                    int menu = sc1.nextInt();
                    System.out.println("===================================");
                    if (menu == 7) {
                        System.out.println("Goodbye");
                        break;
                    } else {
                        String model, name, plat, id;
                        int days, seat, price;
                        switch (menu) {
                            case 1:
                                System.out.println("Enter a car model");
                                model = sc.nextLine();
                                System.out.println("Entar the renting days");
                                days = sc1.nextInt();
                                System.out.println("Entar amount of seats 2/4");
                                seat = sc1.nextInt();
                                System.out.println("Enter car plat NO.");
                                plat = sc.nextLine();
                                System.out.println("Enter customer's Name");
                                name = sc.nextLine();
                                System.out.println("Entar customer's ID number");
                                id = sc.nextLine();
                                price = carsReport(days, seat);
                                String Rp = NumberFormat.getCurrencyInstance(Locale.US).format(price);
                                Report(model, plat, days, name, id, Rp);
                                rentCar(model, plat, name, id, Rp);
                                break;
                            case 2:
                                System.out.println("===============Search===============");
                                System.out.println("Enter the Brand");
                                String mo = sc.nextLine();
                                boolean ceksearch = search(mo);
                                if (ceksearch) {
                                    System.out.println("======This Brand is available======");
                                    System.out.println("====================================");
                                } else {
                                    System.out.println("====This Brand isn't available=====");
                                    System.out.println("====================================");
                                }
                                break;
                            case 3:
                                String[] display;
                                display = Display();
                                System.out.println("=========All the brands that are available in the store=========");
                                System.out.println(Arrays.toString(display));
                                System.out.println("================================================================");
                                break;
                            case 4:
                                System.out.println("Entar car brand ");
                                model=sc.nextLine();
                                System.out.println("Plat NO. ");
                                plat=sc.nextLine();
                                addNewCar(model, plat);
                                break;
                            case 5:
                                viewcar();
                                break;
                            case 6:
                                System.out.println("Enter coustemr ID");
                                id = sc.nextLine();
                                returncar(id);
                                break;
                        }
                        System.out.print("Go Back (y/n): ");
                        back = sc.nextLine();
                    }
                } while (back.equalsIgnoreCase("y"));

            } else {
                System.out.println("=============Try again=============");
            }
        } while (cek.equalsIgnoreCase(w));
    }
    static String r = "==============Welcome==============",
            w = "Invalid Username or Invalid Pasword",
            back;
}
