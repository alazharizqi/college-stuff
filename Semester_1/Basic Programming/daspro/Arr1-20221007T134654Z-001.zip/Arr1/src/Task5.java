/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task5 {

    public static void main(String args[]) {

        Scanner in = new Scanner(System.in);
        System.out.print("rows");
        int isize = in.nextInt();
        System.out.print("columns");
        int jsize = in.nextInt();
        int arr[][] = new int[isize][jsize];
        int array[][] = new int[jsize][isize];
        for (int i = 0; i < isize; i++) {
            for (int j = 0; j < jsize; j++) {
                System.out.print("Enter the elements[" + i + "," + j + "]" + ":");
                arr[i][j] = in.nextInt();
            }
            System.out.println("\n");
        }

        for (int n = 0; n < arr[0].length; n++) {
            for (int m = 0; m < arr.length; m++) {
                array[n][m] = arr[m][n];
                System.out.print(array[n][m] + " ");
            }
            System.out.print("\n");
        }
    }
}
