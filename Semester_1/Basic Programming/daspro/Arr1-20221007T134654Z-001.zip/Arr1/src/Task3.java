/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);

        System.out.print("Enter how many rows:");
        int r = sc.nextInt();
        System.out.print("Enter how many columns:");
        int c = sc.nextInt();
        int arr[][] = new int[r][c];
        String m;
        int l = 0, l1 = 0, n = 50, co = 0, max = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print("Enter the elements[" + i + "," + j + "]" + ":");
                arr[i][j] = sc.nextInt();
            }

        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println("");
        }
        System.out.println("Choose a menu ");
        System.out.println("A.MIN value"
                + "  B.MIN Value&Amount"
                + "  C.Array condition");
        m = sc1.nextLine();

        if ("A".equalsIgnoreCase(m)) {
            int min = arr[0][0];
            for (int i = 0; i < arr.length; i++) {
                for (int j = 0; j < arr[0].length; j++) {
                    System.out.print(arr[i][j] + " ");
                    if (min > arr[i][j]) {
                        min = arr[i][j];
                    }
                }
                System.out.println();
            }
            System.out.println("Smallest value:" + "[" + min + "]");
        } else if ("B".equalsIgnoreCase(m)) {
            int min = arr[0][0];
            for (int i = 0; i < arr.length; i++) {
                for (int j = 0; j < arr[0].length; j++) {
                    System.out.print(arr[i][j] + " ");
                    if (max < arr[i][j]) {
                        max = arr[i][j];
                    }
                    if (arr[i][j] == max) {
                        l = i;
                        l1 = j;
                    }
                    if (min > arr[i][j]) {
                        min = arr[i][j];
                    }
                }
                System.out.println();
            }for (int i = 0; i < arr.length; i++) {
                for (int j = 0; j < arr[0].length; j++) {
                if(arr[i][j]==min)
                    co+=1;
                }
            }
            System.out.println("Smallest value:" + "[" + min + "]");
            System.out.println("Amount:" + "[" + co + "]");
            System.out.println("The biggest number is: [" + max + "] in the index number:" + "[" + l + "." + l1 + "]");
        } else if ("C".equalsIgnoreCase(m)) {
            boolean complete = true;
            for (int i = 0; i < arr.length; i++) {
                for (int j = 0; j < arr[0].length; j++) {
                    if (arr[i][j] == n) {
                        complete = false;
                    }
                }
            }
            if (!(complete)) {
                System.out.println("Yes");
            } else {
                System.out.println("NO");

            }
        }
    }
}
