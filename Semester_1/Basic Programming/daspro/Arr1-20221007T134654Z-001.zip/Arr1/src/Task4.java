/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[][] = new int[3][5];
        int max = 0;
        int max1 = 0;
        int max2 = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print("Enter the elements[" + i + "," + j + "]" + ":");
                arr[i][j] = sc.nextInt();
            }

        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println("");
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                if (max < arr[0][i]) {
                    max = arr[0][i];
                }
                if (max < arr[0][j]) {
                    max = arr[0][j];

                }
                if (max1 < arr[1][i]) {
                    max1 = arr[1][i];
                }
                if (max1 < arr[1][j]) {
                    max1 = arr[1][j];

                }
                if (max2 < arr[2][i]) {
                    max2 = arr[2][i];
                }
                if (max2 < arr[2][j]) {
                    max2 = arr[2][j];
                }
                System.out.print("");
            }
            System.out.println("Largest values:" + "[" + max + "|" + max1 + "|" + max2 + "]");
        }
    }
}
