/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
public class Arr1 {

    public static void main(String[] args) {
        int value[][] = new int[2][3];

        value[1][0] = 30;
        value[1][1] = 21;
        value[1][2] = 67;
        System.out.println(value[0][0]+" "+ value[0][1]+" "+ value[0][2]);
        System.out.println(value[1][0]+" "+ value[1][1]+" "+ value[1][2]);
    }
}
