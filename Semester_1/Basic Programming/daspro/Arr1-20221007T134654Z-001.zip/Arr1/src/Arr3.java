/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Arr3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] value = new int[2][3];
        int i = 0;
        int j = 0;
        while ( i < 2 ) {
            while ( j < 3 ) {
                System.out.print("Enter value number-[" + i + "][" + j + "] ");
                value[i][j] = sc.nextInt();
                j++;
            }
            j = 0;
            System.out.println("------------------------");
            i++;
        }
        i = 0;
        while (i < 2 ) {
            while ( j < 3 ) {
                System.out.print(value[i][j] + " ");
                j++;
            }
            j = 0;
            System.out.println();
            i++;
        }
    }
}

