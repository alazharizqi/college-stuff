/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Arr4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int rowA, columnA;
        System.out.print("Enter row size of Matrix A : ");
        rowA = sc.nextInt();
        System.out.print("Enter Column size of Matrix A : ");
        columnA = sc.nextInt();
        int[][] MatrixA = new int[rowA][columnA];
        System.out.println("Input Element of Matrix A : ");

        int i = 0;
        int j = 0;
        while (i < rowA) {
            while (j < columnA) {
                System.out.print("Matrix A[" + i + "][" + j + "]" + ": ");
                MatrixA[i][j] = sc.nextInt();
                j++;
            }
            j = 0;
            System.out.println();
            i++;
        }
        i = 0;
        System.out.println("The Matrix Output is : ");
        while (i < rowA) {
            while (j < columnA) {
                System.out.print(MatrixA[i][j] + " ");
                j++;
            }
            j = 0;
            System.out.println();
            i++;
        }
    }
}
