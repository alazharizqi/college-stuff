/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection1;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Selection1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        int number;
        System.out.println("Enter Your Number: ");
        number=input.nextInt();
        
        if (number%2==0) {
            System.out.println("Even Number");
        } else {
            System.out.println("Odd Number");
        }
        String output =(number%2==0)?"Even Number" : "Odd Number";
        System.out.println(output);
        // TODO code application logic here
    }
    
}
