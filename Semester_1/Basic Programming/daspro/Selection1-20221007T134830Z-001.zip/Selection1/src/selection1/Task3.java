/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection1;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task3 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        double grade,mid,quiz,assign,grade1,mid1,quiz1,assign1,total;
        
           System.out.println("Ender your semeter's score : ");
           grade = input.nextDouble();
           grade1=grade * 40 / 100;
           System.out.println("Enter your midterm's score : ");
           mid = input.nextDouble();
           mid1=mid * 30 / 100;
           System.out.println("Input grade Quiz : ");
           quiz = input.nextDouble();
           quiz1=quiz * 10 / 100;
           System.out.println("Input grade Assignment : ");
           assign = input.nextDouble();
           assign1=assign * 20 / 100;
           total = grade1 + quiz1 + mid1 + assign1;
           System.out.println("Your final grade is: " + total);
           if (total<65){
           System.out.println("You must take remidial");
           }else{
           System.out.println("You pass the test");
           }
    }       
}

