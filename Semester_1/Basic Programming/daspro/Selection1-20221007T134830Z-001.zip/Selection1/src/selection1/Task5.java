/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection1;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task5 {
    public static void main (String[]args){
    Scanner sc =new Scanner (System.in);
        int cost;
        float discount,total;
        System.out.println("Total purchase : ");
        cost = sc.nextInt();
        if(cost>1000000){
        System.out.println("you get a platinum member dicount of 10%");
        System.out.println("Your total purchase is : "+ cost);
        discount = cost * 10 / 100;
        System.out.printf("Your total discount is %.1f \n", discount);
        total = cost - discount;
        System.out.printf("The total you have to pay is : %.1f \n", total);
        }
        else if(cost>500000){
        System.out.println("you get a Gold member dicount of 5%");
        System.out.println("Your total purchase is : "+ cost);
        discount = cost * 5 / 100;
        System.out.printf("Your total discount is %.1f \n", discount);
        total = cost - discount;
        System.out.printf("The total you have to pay is : %.1f \n", total);
        }
        else if(cost>200000){
        System.out.println("you get a Silver member dicount of 10%");
        System.out.println("Your total purchase is : "+ cost);
        discount = cost * 2 / 100;
        System.out.printf("Your total discount is %.1f \n", discount);
        total = cost - discount;
        System.out.printf("The total you have to pay is : %.1f \n", total);
        }
        else{
        System.out.println("Your total shopping is still not enough to get member discounts");
        System.out.println("Your total purchase is : "+ cost);
        }
    }
}
