/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection1;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Experiment2 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        int score1, score2, average;
        System.out.println("Enter Your Score1: ");
        score1=input.nextInt();
        System.out.println("Enter Your Score2: ");
        score2=input.nextInt();
        average=(score1+score2)/2;

        if (average>=100) {
            average-=5;
        } 
        System.out.println("Your Final Score is: " + average);
    }   
        
}
