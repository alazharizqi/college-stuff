/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection1;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task4 {
    public static void main (String[]args ){
    Scanner sc=new Scanner(System.in);
    int base,food,trans,total;
    float tax,totalsalary;
        System.out.println("Base salary : ");
        base = sc.nextInt();
        System.out.println("Food allowance : ");
        food = sc.nextInt();
        System.out.println("Transportion money : ");
        trans = sc.nextInt();
        total = base + food + trans;
        if(total>=1000000){
        tax = total * 10 / 100;
        totalsalary = total - tax;
        System.out.printf("Total salary is : %.1f \n", totalsalary);
        }else{
        System.out.println("Total salary is : "+ total);
        }
    }
}
