/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
class Task2 {
    static double circumference(double X){
    double A;
    A=2*22*X/7;
    return  A;
    }
    static double area(double Z){
    double B;
    B=22*Z*Z/7;
    return  B;
    }
    public static void main(String[]args){
        Scanner sc = new Scanner (System.in);
        int r;
        System.out.println("Enter the Radius");
        r=sc.nextInt();
        double cir=circumference(r);
        double a=area(r);
        System.out.println("circumference = "+ cir);
        System.out.println("area = "+ a);
    }
}
