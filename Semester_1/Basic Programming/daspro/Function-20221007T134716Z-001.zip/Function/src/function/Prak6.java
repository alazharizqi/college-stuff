/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Prak6 {
    static int hitungLuas (int pjq, int lb){
    int Luas=pjq*lb;
    return Luas;
    }
    
    static int hitungVolume (int tinggi, int a, int b){
    int volme=hitungLuas(a, b)*tinggi;
    return volme;
    }
    
    
    public static void main (String[]args){
    Scanner sc = new Scanner (System.in);
    int p,l,t,L,vol;
        System.out.println("Masukkan Panjang");
        p=sc.nextInt();
        System.out.println("Masukkan lebar");
        l=sc.nextInt();
        System.out.println("Masukkan tinggi");
        t=sc.nextInt();
        
        L=hitungLuas(p, l);
        System.out.println("Luas Persegi Pangng adalah :"+ L);
        vol=hitungVolume(t, p, l);
        System.out.println("Volume balok adalah :"+vol);
    }    
}
