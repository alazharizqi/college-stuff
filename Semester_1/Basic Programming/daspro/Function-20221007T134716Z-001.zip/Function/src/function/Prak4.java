package function;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

class Prak4 {

    static String Check(int E, int F) {
        String cek = null;
        if (E < 0 || F < 0) {
            cek = "less than 0";
        }
        return cek;
    }

    static int Kali(int C, int D) {
        int H;
        H = (C + 10) % (D + 19);
        return H;
    }

    static int Kurang(int A, int B) {
        int X;
        A = A + 7;
        B = B + 4;
        X = Kali(A, B);
        return X;
    }

    public static void main(String[] args) {
        int nilai1, nilai2;
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukan Nilai 1:");
        nilai1 = sc.nextInt();
        System.out.println("Masukan Nilai 2:");
        nilai2 = sc.nextInt();
        String cek = Check(nilai2, nilai2);
        int hasil = Kurang(nilai1, nilai2);
        System.out.println("Hasil akhir adalah :" + hasil);
        System.out.println("Check :" + cek);
    }
}
