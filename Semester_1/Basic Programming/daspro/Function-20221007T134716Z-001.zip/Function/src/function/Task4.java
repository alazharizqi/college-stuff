/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task4 {

    public static void main(String[] args) {
        int B[] = fill();
        System.out.println("The Scores");
        for (int i = 0; i < B.length; i++) {
            System.out.print("[" + B[i] + "]");
        }
        System.out.println();
        int max = getMax(B);
        System.out.println("Maximum Value is: " + max);
        int min = getMin(B);
        System.out.println("Minimum Value is: " + min);
        double avg = getAvg(B);
        System.out.println("Average Value is: " + avg);

    }

    static int[] fill() {
        Scanner sc = new Scanner(System.in);
        int C[] = new int[10];
        for (int i = 0; i < C.length; i++) {
            System.out.print("Enter the Score:" + "(" + (i + 1) + "}:");
            C[i] = sc.nextInt();
        }
        return C;
    }

    static double getAvg(int[] inputArray) {

        double Sum = inputArray[0];
        for (int i = 0; i < inputArray.length; i++) {
            Sum += inputArray[i];
        }
        Sum /= inputArray.length;
        return Sum;
    }

    public static int getMax(int[] inputArray) {
        int maxValue = inputArray[0];
        for (int i = 1; i < inputArray.length; i++) {
            if (inputArray[i] > maxValue) {
                maxValue = inputArray[i];
            }
        }
        return maxValue;
    }

    public static int getMin(int[] inputArray) {
        int minValue = inputArray[0];
        for (int i = 1; i < inputArray.length; i++) {
            if (inputArray[i] < minValue) {
                minValue = inputArray[i];
            }
        }
        return minValue;
    }
}
