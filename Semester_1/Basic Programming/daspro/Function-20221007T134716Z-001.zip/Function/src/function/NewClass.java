/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
public class NewClass {
    public static void t(int i) {
        for (int j = 1; j <=i; j++) {
            System.out.print(j);
        }
    }
    public static int j(int a, int b) {
        return (a+b);
    }
    public static void tm(int a, int b) {
        t(j(a, b));
    }
    public static void main(String[] args) {
        int temp=j(1, 1);
        tm(temp, 5);
    }
}
