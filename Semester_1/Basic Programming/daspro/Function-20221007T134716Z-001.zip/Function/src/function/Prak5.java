/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
class Prak5 {
    static void Tampil(String str, int... a){
        System.out.println("String: "+ str);
        System.out.println("Jumlah argumen/parameter: " + a.length);
        
        for (int i : a){
            System.out.println(i + " ");
        }
        
        System.out.println();
    }
    public static void main (String [] args){
        Tampil("Daspro 2019",100, 200);
        Tampil("Teknologi Indormasi",1, 2, 3, 4, 5);
        Tampil("Polinema");

    }
}
