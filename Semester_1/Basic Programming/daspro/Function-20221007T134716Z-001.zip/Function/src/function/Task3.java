/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

class Task3 {

    public static void main(String[] args) {
        int A[] = fil();
        for (int i = 0; i < A.length; i++) {
            System.out.print("[" + A[i] + "]");
        }
    }

    public static int[] fil() {
        Scanner sc = new Scanner(System.in);
        int C[] = new int[11];
        for (int i = 0; i < C.length; i++) {
            if (i % 2 == 0 || i == 0) {
                System.out.print("Enter the value");
                C[i] = sc.nextInt();
            } else {
            }
        }
        return C;
    }

}
