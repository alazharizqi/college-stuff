/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

class Task1 {

    static int max3(int bil1, int bil2, int bil3) {
        int X = 0;
        if (bil1 > bil2) {
            X = bil1;
        } else {
            X = bil2;
            if (bil2 > bil3) {
                X = bil2;
            }
        }
        if (bil1 < bil3) {
            X = bil3;
        }
        return X;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int no1, no2, no3;
        System.out.println("NO. 1:");
        no1 = sc.nextInt();
        System.out.println("NO. 2:");
        no2 = sc.nextInt();
        System.out.println("NO. 3:");
        no3 = sc.nextInt();
        int max = max3(no1, no2, no3);
        System.out.println("Largest Number is :" + max);
    }
}
