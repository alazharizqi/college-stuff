/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Masukan jumlah Array:");
        int n = sc.nextInt();
        int ns[] = new int[n];
        for (int i = 0; i < ns.length; i++) {
            System.out.println("Masukan array ke-" + i);
            ns[i] = sc.nextInt();
        }
        for (int i = 0; i < ns.length; i++) {
            if (ns[i] % 2 == 0) {
                System.out.println("angka genap:" + ns[i]);
            }
        }
        for (int i = 0; i < ns.length; i++) {
            if (ns[i] % 2 == 1) {
                System.out.println("angka ganjil:" + ns[i]);
            }
        }
    }
}
