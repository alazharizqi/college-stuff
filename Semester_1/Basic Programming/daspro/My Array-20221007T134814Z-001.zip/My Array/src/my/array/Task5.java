/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, Largest;
        System.out.print("Enter how many elements in the array:");
        n = sc.nextInt();
        int[] intArr = new int[n];
        for (int i = 0; i < intArr.length; i++) {
            System.out.print("Enter the elements in the index NO." + i + ":");
            intArr[i] = sc.nextInt();
        }
        System.out.println("The Array");
        for (int i = 0; i < intArr.length; i++) {
            System.out.print("[" + intArr[i] + "]");
        }
        Largest = intArr[0];
        for (int i = 0; i < n; i++) {
            if (Largest < intArr[i]) {
                Largest = intArr[i];
            }
        }
        System.out.println("");
        System.out.println("Largest value:" + "[" + Largest + "]");
    }
}
