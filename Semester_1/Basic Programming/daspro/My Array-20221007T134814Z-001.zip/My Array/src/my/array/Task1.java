/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] ns = new int[5];
        int i;
        for (i = 0; i < 5; i++) {
            int n;
            System.out.println("Entar a number");
            ns[i] = sc.nextInt();
        }
        System.out.print(""+ns[4]+" ");
        System.out.print(ns[3]+" ");
        System.out.print(ns[2]+" ");
        System.out.print(ns[1]+" ");
        System.out.print(ns[0]+" ");


    }
}
