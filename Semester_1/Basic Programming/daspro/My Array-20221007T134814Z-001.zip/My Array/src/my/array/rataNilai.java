/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class rataNilai {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        int total = 0;
        double rata;
        System.out.println("Masukan jumlah Mahasiswa:");
        n = sc.nextInt();
        int[] nilaiMHS = new int[n];
        for (int i = 0; i < nilaiMHS.length; i++) {
            System.out.println("Masukan Nilai Mahasiswa ke-" + (i + 1) + ":");
            nilaiMHS[i] = sc.nextInt();
        }
        for (int i = 0; i < nilaiMHS.length; i++) {
            total += nilaiMHS[i];

        }
        int i = 0;
        if (nilaiMHS[i] > 70) {
            rata = total / nilaiMHS.length;
            System.out.println("Rata yang lulus:" + rata);
            
            rata = total / nilaiMHS.length;
            rata =100 - rata;
            System.out.println("Rata yang Tidak lulus:" + rata);
        }

    }

}
