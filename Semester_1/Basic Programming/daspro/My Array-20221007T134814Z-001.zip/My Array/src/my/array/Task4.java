/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        int[] newArr = null;
        System.out.print("Enter how many elements in the array:");
        n = sc.nextInt();
        int[] intArr = new int[n];
        for (int i = 0; i < intArr.length; i++) {
            System.out.print("Enter the elements in the index NO." + i + ":");
            intArr[i] = sc.nextInt();
        }
        System.out.println("The Array");
        for (int i = 0; i < intArr.length; i++) {
            System.out.print("[" + intArr[i] + "]");
        }
        System.out.println("");
        System.out.print("Enter Element to be deleted : ");
        int elem = sc.nextInt();

        for (int i = 0; i < intArr.length; i++) {
            if (intArr[i] == elem) {
                newArr = new int[intArr.length - 1];
                for (int index = 0; index < i; index++) {
                    newArr[index] = intArr[index];
                }
                for (int j = i; j < intArr.length - 1; j++) {
                    newArr[j] = intArr[j + 1];
                }
                break;
            }
        }
        System.out.println("Elements -- ");
        for (int i = 0; i < newArr.length; i++) {
            System.out.print("[" + newArr[i] + "]");
        }
    }
}
