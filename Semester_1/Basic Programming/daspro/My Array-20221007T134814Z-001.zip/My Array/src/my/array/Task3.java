/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.array;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Masukan jumlah MK yang anda ambil:");
        int mk = sc.nextInt();
        int amk[] = new int[mk];
        int sks[] = new int[mk];
        double fs[] = new double[mk];
        double total = 0, avg = 0;
        String c[] = new String[mk];
        String s[] = new String[mk];

        for (int i = 0; i < c.length; i++) {
            System.out.print("masukan nama MK:" + (i + 1) + ":");
            c[i] = sc1.nextLine();
        }
        for (int i = 0; i < c.length; i++) {
            System.out.print("masukan bobot SKS:" + c[i] + ":");
            sks[i] = sc.nextInt();
            System.out.print("masukan nilai:" + c[i] + "(A,B+,B,C+,C,D,E):");
            s[i] = sc1.nextLine();

            if (s[i].equalsIgnoreCase("A")) {
                fs[i] = 4;
                if (s[i].equalsIgnoreCase("B+")) {
                    fs[i] = 3.5;
                }
                if (s[i].equalsIgnoreCase("B")) {
                    fs[i] = 3;
                }
                if (s[i].equalsIgnoreCase("C+")) {
                    fs[i] = 2.5;
                }
                if (s[i].equalsIgnoreCase("C")) {
                    fs[i] = 2;
                }
                if (s[i].equalsIgnoreCase("D")) {
                    fs[i] = 1;
                }
                if (s[i].equalsIgnoreCase("E")) {
                    fs[i] = 0;
                } else {
                }
            }
        }
        for (int i = 0; i < fs.length; i++) {
            total += fs[i];
        }
        avg = total / mk;
        System.out.println("IP Semestar Anda adalah=" + avg);
    }
}
