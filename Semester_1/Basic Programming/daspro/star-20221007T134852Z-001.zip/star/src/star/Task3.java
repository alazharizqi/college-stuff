/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package star;

import java.util.Scanner;

public class Task3 {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Entar a number");
        int n = sc.nextInt();

        for (int i = 1; i <= n; i++) {
            if (i == n || i == 1) {
                for (int j = 0; j <= n; j++) {
                    System.out.print(n);
                }
                System.out.println(" ");
            } else {
                int m, s;
                for (m = 0; m < 1; m++) {
                    System.out.print(n);
                }
                for (s = n - 2; s >= 0; s--) {
                    if (n > 9) {
                        System.out.print("  ");
                    } else if (n > 99) {
                        System.out.print("   ");
                    } else {
                        System.out.print(" ");
                    }
                }
                for (m = n; m > n - 1; m--) {
                    System.out.print(n);
                }
                System.out.println("");
            }
        }
    }
}
