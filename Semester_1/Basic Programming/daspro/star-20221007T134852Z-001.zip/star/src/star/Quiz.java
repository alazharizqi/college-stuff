/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package star;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
import java.util.Random;

public class Quiz {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        char menu = 'y';
        do {
            int number = random.nextInt(10) + 1;
            boolean success = false;
            do {
                System.out.print("Guess the numbers (1-10): ");
                int answer = sc.nextInt();
                sc.nextLine();
                success = (answer == number);
                if (answer > number) {
                    System.out.println("the number is bigger than the correct answer");
                } else if (answer < number) {
                    System.out.println("the number is smaller than the correct answer");
                } else {
                    System.out.println("correct answer!");
                }
            } while (!success);
            System.out.print("Do you want to repeat the game (Y/y)?");
            menu = sc.findInLine(".").charAt(0);
            sc.nextLine();
        } while (menu == 'y' || menu == 'Y');
    }
}
