/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task3 {
    static int prime(int y,int i){
         if(i < y){
            if(y % i != 0) 
            {
                return(prime(y, ++i));
            } 
            else
            {
                return 0; 
            }
        }
        return 1;
    
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Value");
        n=sc.nextInt();
        int A=prime(n, 2);
        if(A==1){
            System.out.println("This is a prime number");
        }else {
           System.out.println("This isn't a prime number");
        }
    }
}
