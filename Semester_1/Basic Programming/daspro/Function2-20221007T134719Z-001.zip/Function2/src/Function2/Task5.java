/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
public class Task5 {
    static int s=1, o;
    static int F(int x, int z){
        if(s==12){
        return o;
        }else{
            o = x+z;
            s++;
        return F(z, o);
        }
    }
    public static void main(String[] args) {
        int fn = 0, sn = 1;
        int f=F(fn, sn);
        System.out.println("Pairs of newborn rabbits after 12 months  = "+f);

    }
}
