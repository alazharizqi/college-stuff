/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */

import java.util.Scanner;
public class Experiment3 {
    static double hitungBunga(double saldo, int tahun ){
        if (tahun==0){
            return (saldo);
        }else {
            return (1.11*hitungBunga(saldo, tahun-1));
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        double saldoAwal;
        int tahun;
        System.out.print("jumlah saldo awal:");
        saldoAwal=sc.nextInt();
        System.out.print("lamanya menabung (tahun):");
        tahun=sc.nextInt();
        System.out.print("Jumlah uang setelah "+ tahun+" tahun: ");
        System.out.println(hitungBunga(saldoAwal, tahun));
    }
}
