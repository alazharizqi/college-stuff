package Function2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author MICROSOFT
 */
public class Experiment1 {

    static int Recursive(int n) {
        if (n == 0) {
            return 1;
        } else {
            return (n * Recursive(n-1));
        }
    }

    static int Factorial(int n) {
        int fac = 1;
        for (int i = n; i >= 1; i--) {
            fac=fac*i;
        }
        return fac;
    }
    public static void main(String args[]){
        System.out.println(Recursive(5));
        System.out.println(Factorial(5));
    }
}
