/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Experiment2 {
    static int hitungPangkat(int x, int y){
        if(y==0){
            return (1);
        }else {
            return (x*hitungPangkat(x,y-1));
        }
    }
    public static void main (String []args ){
    Scanner sc = new Scanner (System.in);
    int number, rank;
        System.out.print("counted numbers:");
        number=sc.nextInt();
        System.out.print("Rank:");
        rank=sc.nextInt();
        System.out.println(hitungPangkat(number, rank));
    }
}


