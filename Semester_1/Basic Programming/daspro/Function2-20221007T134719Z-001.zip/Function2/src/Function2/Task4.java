/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task4 {
    static int FPB(int x, int z){
        int o = x%z;
        if(o==0){
        return z;
        }else{
        return FPB(z, o);
        }
    }
    public static void main(String[] args) {
        Scanner sc =new Scanner (System.in);
        int fn, sn;
        System.out.println("Number (1)");
        fn=sc.nextInt();
        System.out.println("Number (2)");
        sn=sc.nextInt();
        int fpb=FPB(fn, sn);
        System.out.println("FPB = "+fpb);
    }
}
