/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Task1 {

    static int Descending(int n) {
        if (n == 0) {
            return (n);
        } else {
            System.out.print(n + ",");
            return (Descending(n - 1));
        }
    }

    static void Iterative(int n) {
        for (int i = n; i >= 0; i--) {
            System.out.print(i + ",");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("Value");
        n = sc.nextInt();
        System.out.println("Descending");
        System.out.println(Descending(n));
        System.out.println("Iterative");
        Iterative(n);

    }
}
