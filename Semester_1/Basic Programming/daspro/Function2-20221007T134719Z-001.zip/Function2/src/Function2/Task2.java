/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Task2 {
    static int Recursive(int n) {
        if (n == 0) {
            return 1;
        } else {
            return (Recursive(n-1)+n);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Value");
        n=sc.nextInt();
        System.out.println(Recursive(n)-1);
    }
}
