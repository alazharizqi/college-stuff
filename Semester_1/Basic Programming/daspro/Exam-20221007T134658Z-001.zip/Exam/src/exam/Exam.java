/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Exam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int bm,by,bd,cm,cy,cd;
        Scanner sc = new Scanner(System.in);
        System.out.println("birth day");
        bd =sc.nextInt();
        System.out.println("birth month");
        bm =sc.nextInt();
        System.out.println("birth year");
        by =sc.nextInt();
        System.out.println("curent day");
        cd =sc.nextInt();
        System.out.println("curent month");
        cm =sc.nextInt();
        System.out.println("curent year");
        cy =sc.nextInt();
        
        

                
        
            System.out.print("your age is : "+ (cy-by));
            System.out.print(" years");
            System.out.print(" , "+ (cm-bm));
            System.out.print(" months");
            System.out.print(" and "+(cd-bd));
            System.out.print(" days");
                    
            
        }
        
        
        
    
    
}
