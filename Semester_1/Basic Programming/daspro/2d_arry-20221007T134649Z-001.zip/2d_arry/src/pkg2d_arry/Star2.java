/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2d_arry;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Star2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter how many rows:");
        int r = sc.nextInt();
        System.out.print("Enter how many columns:");
        int c = sc.nextInt();
        String  star[][] = new String [r][c];
        
        for (int i = 0; i < star.length ; i++) {
            for (int j = 0; j < star[0].length; j++) {
                star[i][j]="*";
                if (i==j||i<j) {
                System.out.print(star[i][j]);
                }else{
                    System.out.print(" "); 
                }
            }System.out.println("");
        }
    }
}               
