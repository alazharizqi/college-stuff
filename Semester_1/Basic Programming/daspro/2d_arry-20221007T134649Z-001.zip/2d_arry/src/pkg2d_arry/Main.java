/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2d_arry;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        char re;
        System.out.println("====================================");
        System.out.println(" Mathematical operation on 2 arrays ");
        System.out.println("====================================");
        System.out.println("  Would you like to use (Y||N)");
        String b = sc1.nextLine();
        if ("y".equalsIgnoreCase(b)) {
            do {
                do {
                    System.out.println("====================================");
                    System.out.print("Enter how many rows:");
                    int r = sc.nextInt();
                    System.out.print("Enter how many columns:");
                    int c = sc.nextInt();
                    System.out.println("====================================");
                    int arr1[][] = new int[r][c];
                    int arr2[][] = new int[r][c];
                    int arr3[][] = new int[r][c];
                    System.out.println(" First array");
                    for (int i = 0; i < arr1.length; i++) {
                        for (int j = 0; j < arr1[0].length; j++) {
                            System.out.print("Enter the elements[" + i + "," + j + "]");
                            arr1[i][j] = sc.nextInt();
                        }
                    }
                    System.out.println("====================================");
                    System.out.println(" Second array");
                    for (int i = 0; i < arr2.length; i++) {
                        for (int j = 0; j < arr2[0].length; j++) {
                            System.out.print("Enter the element[" + i + "," + j + "]");
                            arr2[i][j] = sc.nextInt();
                        }
                    }
                    System.out.println("====================================");
                    System.out.println(" First array");
                    for (int i = 0; i < arr1.length; i++) {
                        for (int j = 0; j < arr1[0].length; j++) {
                            System.out.print(arr1[i][j] + " ");
                        }
                        System.out.println();
                    }
                    System.out.println("====================================");
                    System.out.println(" Second array");
                    for (int i = 0; i < arr2.length; i++) {
                        for (int j = 0; j < arr2[0].length; j++) {
                            System.out.print(arr2[i][j] + " ");
                        }
                        System.out.println();
                    }
                    System.out.println("====================================");
                    System.out.println(" Would you like to operate a mathematical operation(Y||N)");
                    String a = sc1.nextLine();
                    if ("y".equalsIgnoreCase(a)) {
                        do {
                            do {
                                System.out.println(" What mathematical operation you would like to do with those arrays(+,-,*,/)?");
                                String math = sc1.nextLine();
                                switch (math) {
                                    case "+":
                                        for (int i = 0; i < arr3.length; i++) {
                                            for (int j = 0; j < arr3[0].length; j++) {
                                                arr3[i][j] = arr1[i][j] + arr2[i][j];
                                            }
                                        }
                                        break;
                                    case "-":
                                        for (int i = 0; i < arr3.length; i++) {
                                            for (int j = 0; j < arr3[0].length; j++) {
                                                arr3[i][j] = arr1[i][j] - arr2[i][j];
                                            }
                                        }
                                        break;
                                    case "*":
                                        for (int i = 0; i < arr3.length; i++) {
                                            for (int j = 0; j < arr3[0].length; j++) {
                                                arr3[i][j] = arr1[i][j] * arr2[i][j];
                                            }
                                        }
                                        break;
                                    case "/":
                                        for (int i = 0; i < arr3.length; i++) {
                                            for (int j = 0; j < arr3[0].length; j++) {
                                                arr3[i][j] = arr1[i][j] / arr2[i][j];
                                            }
                                        }
                                    default:
                                }
                                System.out.println(" Result");
                                System.out.println("====================================");
                                for (int i = 0; i < arr3.length; i++) {
                                    for (int j = 0; j < arr3[0].length; j++) {
                                        System.out.printf(arr3[i][j] + " ");
                                    }
                                    System.out.println();
                                }
                                System.out.println("====================================");
                            } while ("n".equalsIgnoreCase(a));
                            System.out.print("Do you want to repeat any other mathematical operation (Y/N)?");
                            re = sc1.findInLine(".").charAt(0);
                            sc1.nextLine();
                        } while (re == 'y' || re == 'Y');
                    } else {
                    }
                } while ("n".equalsIgnoreCase(b));
                System.out.print("Do you want to repeat (Y/N)?");
                re = sc1.findInLine(".").charAt(0);
                sc1.nextLine();
            } while (re == 'y' || re == 'Y');
        } else {
        }
    }
}
