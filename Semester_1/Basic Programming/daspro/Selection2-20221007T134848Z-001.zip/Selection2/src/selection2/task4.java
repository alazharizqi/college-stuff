/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
    public class task4 {
	public static void main(String[] args){
	    Scanner sc = new Scanner(System.in);
	    Scanner sc1 = new Scanner(System.in);
	    int menu;
	    double area, side, pedestal, height, radius;
	    char menu2;
	    
            System.out.println("Menu: ");
            System.out.println("Choose menu");
	    System.out.println("1. Two dimensional shape");
	    System.out.println("2. Three dimensional shape");
	    menu = sc.nextInt();
	    
            if (menu == 1) {
	        System.out.println("Choose shape: ");
	        System.out.println("a. Square");
	        System.out.println("b. Triangle");
	        menu2 = sc1.next().charAt(0);
	        if (menu2 == 'a') {
	            System.out.println("What is the measurement of the square's side: ");
	            side = sc.nextDouble();
	            area = side * side;
	            System.out.println("Area : " + area);
	            }
	        else if (menu2 == 'b') {
	            System.out.println("What is the measurement of the triangle's pedestal: ");
	            pedestal = sc.nextDouble();
	            System.out.println("What is the measurement of the triangle's height: ");
	            height = sc.nextDouble();
	            area = (pedestal * height)/2;
	            System.out.println("Area: " + area);
	            }
	        }
	    else if (menu == 2) {
	        System.out.println("Choose shape: ");
	        System.out.println("a. Cube");
	        System.out.println("b. Tube");
	        menu2 = sc1.next().charAt(0);
	            if (menu2 == 'a') {
	                System.out.println("What is the measurement of the cube's side: ");
	                side = sc.nextDouble();
	                area = side * side * side;
	                System.out.println("Volume: " + area);
	            }
	            else if (menu2 == 'b') {
	                System.out.println("What is the measurement of the tube's radius: ");
	                radius = sc.nextDouble();
	                System.out.println("What is the measurementof the tube's height: ");
	                height = sc.nextDouble();
	                area = (3.14 * radius * radius) * height;
	                System.out.println("Volume: " + area);
	            }
	        }
	    }
	}

