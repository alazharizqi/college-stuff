/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Experiment1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        int score;
        System.out.println("Enter test score (0 - 100): ");
        score = sc.nextInt();
        if (score >= 0 && score <= 100){
            if (score >= 90 && score <=100){
                System.out.println("Score A, EXCELLENT!");
            }else if(score >=80 && score<=89){
                System.out.println("Score B, Keep your achievements!");
            }else if(score >=60 && score<=79) {
                System.out.println("Score C, Keep your achievements!");
            }else if(score >=50 && score<=59) {
                System.out.println("Score D, Keep your achievements!");
            }else {
                System.out.println("Score E, DO NOT PASS!");
            }
        }else if (score<0){
            System.out.println("The value you entered is less than 0");
        }else if (score>100){
            System.out.println("The value you entered is more than 100");
        }else {
            System.out.println("The value you entered is invalid");
        }
    }
}
               
    

