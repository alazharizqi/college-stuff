/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class task2 {
    public static void main(String []args){
    Scanner sc = new Scanner(System.in);
    String username,password;
        System.out.println("Username");
        username=sc.nextLine();
        if (username.equalsIgnoreCase("College Student")) {
            System.out.println("Password");
            password=sc.nextLine();
            if (password.equals("SeCreT")){
                System.out.println("LOGGED IN");
            }else {
                System.out.println("wrong password!");
            }
        }
        else {
            System.out.println("wrong username!");
        }  
    }
}
