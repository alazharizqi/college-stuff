/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class task1 {
    public static void main(String[]args){
    Scanner sc = new Scanner(System.in);
    int side1, side2, side3;
    
        System.out.println("To determine the triangle's type follow the instructions below");
        System.out.println("enter side 1");
        side1= sc.nextInt();
        System.out.println("enter side 2");
        side2= sc.nextInt();
        System.out.println("enter side 3");
        side3= sc.nextInt();
        
        if (side1 == side2) {
            if (side2 == side3){
            System.out.println("the triangle is equilateral");
        }
            else {
            System.out.println("the triangle is isosceles");
            }
            
    }
        else if (side1!=side2) {
            if(side1==side3)
            System.out.println("the triangle is isosceles");
        else if (side2==side3){
            System.out.println("the triangle is isosceles");
        }
        else{
            System.out.println("the triangle is just any");
        }     
        }
    }
}    
