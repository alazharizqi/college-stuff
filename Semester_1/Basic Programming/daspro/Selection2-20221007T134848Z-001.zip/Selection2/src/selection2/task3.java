/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
    public class task3 {
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	Scanner sc1 = new Scanner(System.in);
	String foodName;
	int foodPrice, delivery, total;
	
        System.out.print("FOOD: ");
	foodName = sc.nextLine();
	System.out.print("PRICE: ");
	foodPrice = sc1.nextInt();
	System.out.print("Do you want express delivery (0 = no, 1 = yes)? ");
	delivery = sc1.nextInt();
	    if (delivery==0) {
	       if (foodPrice<100000) {
	            total = foodPrice + 20000;
	            System.out.println("RECEIPT");
	            System.out.println(foodName + "\t\t\t\tRp " + foodPrice);
	            System.out.println("Delivery cost" + "\t\t\tRp 20000");
	            System.out.println("TOTAL" + "\t\t\t\tRp " + total);
	            }
	            else if (foodPrice>=100000) {
	                total = foodPrice + 30000;
	                System.out.println("RECEIPT");
	                System.out.println(foodName + "\t\t\t\tRp " + foodPrice);
	                System.out.println("Delivery cost" + "\t\t\tRp 30000");
	                System.out.println("TOTAL" + "\t\t\t\tRp " + total);
	            }
	        }
	    else if (delivery==1) {
                    if (foodPrice<100000) {
	                total = foodPrice + 20000 + 25000;
	                System.out.println("RECEIPT");
	                System.out.println(foodName + "\t\t\t\tRp " + foodPrice);
	                System.out.println("Delivery cost" + "\t\t\tRp " + (20000 + 25000));
	                System.out.println("TOTAL" + "\t\t\t\tRp " + total);
	                
	            }
	            else if (foodPrice>=100000) {
	                total = foodPrice + 30000 + 25000;
	                System.out.println("RECEIPT");
	                System.out.println(foodName + "\t\t\t\tRp " + foodPrice);
	                System.out.println("Delivery cost" + "\t\t\tRp " + (30000 + 25000));
	                System.out.println("TOTAL" + "\t\t\t\tRp " + total);
	            }
	    }	    
        }
}

