public class Exercise {
	public static void main(String[] args){
		System.out.println("-------------------------------------");
		System.out.println("Biodata New Students 2019 in Polinema");
		System.out.println("NIM           : 1941720237");
		System.out.println("NAME          : OMAR ALMAKTARY");
		System.out.println("DEPARTEMENT   : IT ");
		System.out.println("ADRESS        : MALANG");
		System.out.println("-------------------------------------");
	}
}