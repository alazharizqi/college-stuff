import java.util.Scanner;
public class Omar {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int land, total;
	Float tax = 1.5F;
	Float promo = 5/100F;
	Int landPrice = 13000000;
	System.out.println("insert how much land you want to buy");
	land = sc.nextln ();
	total = landPrice*land+tax-promo;
	System.out.println("Final Price" + total);



	}
}