import java.util.Scanner;

public class quiz1_Ahmad{
	public static void main(String[] args) {
		int luas,hargaawal = 1300000,hargaLuas,diskon1,diskon2,pajak1,total;
		Scanner masuk = new Scanner (System.in);
		System.out.print("Please input large of land(M2) \t: ");
		luas = masuk.nextInt();
		hargaLuas = luas * hargaawal;
		diskon1 = hargaLuas * 5 / 100;
		diskon2 = hargaLuas - diskon1;
		pajak1 = hargaLuas * 15 / 1000;
		total = diskon2 + pajak1;
		System.out.println("----------------------------------------------");
		System.out.println("Land cost\t\t\t: Rp."+ hargaLuas);
		System.out.println("Discount \t\t\t: Rp."+ diskon1);
		System.out.println("Tax \t\t\t\t: Rp."+ pajak1);
		System.out.println("Total payment \t\t\t: Rp."+ total);
	}
}