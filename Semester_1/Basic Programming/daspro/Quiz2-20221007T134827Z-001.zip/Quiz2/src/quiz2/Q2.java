/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Q2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int r, c;
        System.out.println("rows ");
        r = sc.nextInt();
        System.out.println("columns");
        c = sc.nextInt();
        int[][] arr = new int[r][c];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print("elemnts" + i + "," + j + ":");
                arr[i][j] = sc.nextInt();
            }
        }
        System.out.println("array");
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print(" " + arr[i][j]);
            }
            System.out.println();
        }

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                int l1 = j;
                if (arr[i][j] < 5) {
                    System.out.println("coulmn" + "[" + l1 + "]" + "[number][" + arr[i][j] + "]");
                }
            }
        }
    }
}
