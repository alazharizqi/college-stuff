/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class Quiz2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter n");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print("*");
                if (i == j) {
                    System.out.print(" ");
                }

            }
            System.out.println(" ");
        }
    }
}
