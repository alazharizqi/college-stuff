/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
public class task3 {

    public static void main(String[] args) {

        int b = 5, a = 1, i;
        for (i = 0; i < 2; i++) {
            a++;
            System.out.print(i);
        }
        System.out.print("1" + i);
        System.out.print(a);
        for (i = 0; i < 1; i++) {
            System.out.print(b);
            System.out.print(b + 3);
        }

    }
}
