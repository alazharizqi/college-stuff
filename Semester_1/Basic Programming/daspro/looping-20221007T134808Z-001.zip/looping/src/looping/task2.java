/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class task2 {

    public static void main(String[] args) {
        int number, i, tn, oddSquareSum = 0, count = 0, oddSum = 0;
        double avg;
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter any Odd Number : ");
        number = sc.nextInt();

        for (i = 1; i <= number; i++) {
            if (i % 2 != 0) {
                oddSum += i;
                count++;
                oddSquareSum += i * i;
            }
        }
        tn = (number / 2) + 1;
        System.out.println("\n The Number of Odd Numbers form 1 to " + number + " = " + tn);
        System.out.println("\n The Sum of Odd Numbers upto " + number + "  =  " + oddSum);
        System.out.println("\n The Sum of Square Odd Numbers upto " + number + "  =  " + oddSquareSum);
        avg = (double) oddSquareSum / count;
        System.out.println("\n The Average of Odd Numbers upto " + number + " = " + avg);
    }
}
