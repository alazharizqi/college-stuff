/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;

public class task1 {

    public static void main(String[] args) {
        int number, tn, i, count = 0, evenSum = 0;
        double avg;
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter any Even Number : ");
        number = sc.nextInt();

        for (i = 1; i <= number; i++) {
            if (i % 2 == 0) {
                evenSum += i;
                count++;
            }
        }
        tn = (number / 2);
        System.out.println("\n The Number of Even Numbers form 1 to " + number + " = " + tn);
        System.out.println("\n The Sum of Even Numbers upto " + number + "  =  " + evenSum);
        avg = (double) evenSum / count;
        System.out.println("\n The Average of Even Numbers upto " + number + " = " + avg);
    }
}
