/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class looping3 {
    public static void main (String[]args){
    Scanner sc = new Scanner (System.in);
    int n,b,i,c;
    double avg, total;
        System.out.println("====PROGRAM LOOP WITH CONTINUE=====");
        b=0; 
        c=0; 
        for (i=0;i<5;i++){
            System.out.println("Enter number :");
            n=sc.nextInt();
            if (n>=50) continue;
               b+=n;
               c++;
        }
        total=(double)b;
        System.out.printf("Total number less than 50: %2f \n", total);
        avg=(double)b/c;
        System.out.printf("Average number less than 50: %2f \n", avg);
    }
}
