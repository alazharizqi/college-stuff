/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class looping2 {
    public static void main(String[]args){
    Scanner sc= new Scanner (System.in);
    int n,b;
        System.out.println("===PROGRAM LOOP WITH BREAK===");
        b=0;
        do
        {
           System.out.println("Inster a number");
            n=sc.nextInt();
            b+=n;
            if (b>50) break; 
        }
        while (true);
        System.out.printf("the number stops when the total is : %d \n ",b);
    }
}
