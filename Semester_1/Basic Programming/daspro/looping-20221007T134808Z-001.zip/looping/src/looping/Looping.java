/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author MICROSOFT
 */
import java.util.Scanner;
public class Looping { 
    public static void main(String[] args) {
        int n, fac,i; 
        System.out.println("===Program Calculates Factorial Values with for===");
        System.out.print("Enter number :");
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        fac= 1;
        i=1;
        do 
        {
            fac=fac*i;
            i++;
        }
        while (i<=n);
            
        
        System.out.printf("Factorial value of that number is : %d \n", fac);
    }    
}
